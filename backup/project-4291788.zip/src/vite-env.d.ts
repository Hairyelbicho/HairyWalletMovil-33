
/// <reference types="vite/client" />

declare const __BASE_PATH__: string;
